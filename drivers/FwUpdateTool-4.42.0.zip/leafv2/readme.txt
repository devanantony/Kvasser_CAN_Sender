
===========================================================================
Firmware for 
  o  Kvaser Leaf Light v2 (all types)
  o  Kvaser Mini PCI Express HS (all types)
  o  Kvaser USBcan Light 2xHS
===========================================================================

Before you update the firmware, you must install the driver routines
and the hardware. The procedure for this is described in a separate
document and also on our web site, www.kvaser.com.

If you can read data like the serial number in the "Kvaser Hardware" program
(accessible from the Control Panel) then everything works OK and you can
proceed with updating the firmware.


To update the firmware:

1) Start "Update.exe".

2) These instructions are displayed. 
   Click Next to continue.

3) A list of supported and currently connected Kvaser devices will now appear.
   Select the device(s) you want to upgrade. 
   Click Next to continue.

4) Release notes for the selected Kvaser devices will now be available.
   Click the button(s) to open and read the individual release notes. 

5) Click the Next button.

6) Click the Start Upgrade button. The programming will now start.
   Typically it takes a few seconds per device.

8) You can watch the progress in the output window. When the
   programming is done, the text "Success!" should appear in the status
   window. If not, check the output window for error messages.
   You can right click in the output window to copy its contents
   to the clipboard, if needed.

9) Close the Update program.

10) Start "Kvaser Hardware" again and check that all Kvaser devices are
    listed.


===========================================================================
Those of you who are developing your own programs and want to update
the firmware from within another program - please contact us at
support@kvaser.com.  There is a command-line program and a DLL
available, but they are currently not documented anywhere.
===========================================================================

